/* ==========================================
   Top Navigation Persistent Highlight

   - When you hover a top-level nav item, its link is highlighted.
   - When you move down into that item's dropdown/mega-menu,
     the same link stays highlighted.
   - When you leave BOTH the nav item and its dropdown,
     the highlight is removed.
   ========================================== */

document.addEventListener('DOMContentLoaded', function () {
  var header = document.querySelector('.site-header');
  if (!header) return;

  // All top-level nav <li> items
  var navItems = header.querySelectorAll('.site-nav__item, .site-nav > li');
  var activeLink = null;
  var clearTimer = null;

  function setActive(link) {
    if (activeLink === link) return;
    if (activeLink) {
      activeLink.classList.remove('is-open');
    }
    activeLink = link;
    if (activeLink) {
      activeLink.classList.add('is-open');
    }
  }

  function clearActive() {
    if (activeLink) {
      activeLink.classList.remove('is-open');
      activeLink = null;
    }
  }

  function scheduleClear() {
    if (clearTimer) clearTimeout(clearTimer);
    clearTimer = setTimeout(clearActive, 80); // small delay to avoid flicker
  }

  function cancelClear() {
    if (clearTimer) {
      clearTimeout(clearTimer);
      clearTimer = null;
    }
  }

  navItems.forEach(function (item) {
    var link = item.querySelector('.site-nav__link');
    if (!link) return;

    // Try to find the corresponding dropdown / megamenu for this item
    var menu = null;
    var controls = link.getAttribute('aria-controls');
    if (controls) {
      menu = document.getElementById(controls);
    }
    if (!menu) {
      // fallback for themes without aria-controls wiring
      menu = item.querySelector('.megamenu, .site-nav__dropdown');
    }

    // Entering the item or its menu -> keep / set highlight
    function handleEnter() {
      cancelClear();
      setActive(link);
    }

    // Leaving the item or its menu -> maybe clear (after tiny delay)
    function handleLeave() {
      scheduleClear();
    }

    item.addEventListener('mouseenter', handleEnter);
    item.addEventListener('mouseleave', handleLeave);

    if (menu) {
      menu.addEventListener('mouseenter', handleEnter);
      menu.addEventListener('mouseleave', handleLeave);
    }
  });
});